const PROMPT_ASSET_URI = "plugin://package/assets/prompts/default.txt";

function buildCard(trigger) {
  return {
    resultType: "card",
    card: {
      title: "AstrBot Template",
      body:
        "QuickJS template entry is ready.\n" +
        `Trigger: ${trigger}\n` +
        `Prompt asset: ${PROMPT_ASSET_URI}`,
      status: "info",
      fields: [
        { label: "runtimeKind", value: "js_quickjs" },
        { label: "entry", value: "runtime/index.js#handleEvent" }
      ]
    }
  };
}

export function handleEvent(context) {
  const trigger = String(context?.trigger || "unknown");
  if (trigger === "on_plugin_entry_click") {
    return buildCard(trigger);
  }
  return {
    resultType: "text",
    text:
      `Template runtime executed for ${trigger}. ` +
      `Packaged prompt asset: ${PROMPT_ASSET_URI}`
  };
}
