# AstrBot 插件模板

这个模板同时保留两套入口：

- 桌面端 AstrBot 插件入口：`main.py` + `metadata.yaml`
- Android 外部执行入口：`android-execution.json` + `runtime/index.js`

Android 外部执行的正式方向已经切到 `JS / QuickJS`，模板也同步使用：

- `entryPoint.runtimeKind = js_quickjs`
- `entryPoint.path = runtime/index.js`
- `entryPoint.entrySymbol = handleEvent`

## 模板内容

- `main.py`
- `metadata.yaml`
- `manifest.json`
- `android-execution.json`
- `runtime/index.js`
- `_conf_schema.json`
- `requirements.txt`
- `README.md`
- `assets/prompts/default.txt`
- `package-plugin.ps1`

## 复制后优先修改

1. `metadata.yaml`
2. `manifest.json`
3. `android-execution.json`
4. `main.py`
5. `runtime/index.js`
6. `_conf_schema.json`
7. `README.md`

## Android 最小样例说明

`runtime/index.js` 给出一个最小、同步、可绑定的 QuickJS 入口骨架：

- `on_plugin_entry_click` 返回 `card`
- `on_command` 返回 `text`
- 保留 `plugin://package/...` 资源 URI 写法示例

这份模板只声明“入口合同与样例资产已迁到 QuickJS”，不会把未来能力写成当前已实现。

## 打包

在模板目录执行：

```powershell
.\package-plugin.ps1
```

默认产物：

```text
dist\astrbot_plugin_template.zip
```
