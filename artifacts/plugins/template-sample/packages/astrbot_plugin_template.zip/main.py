from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, register


@register(
    "astrbot_plugin_template",
    "your_name",
    "AstrBot plugin template aligned with the Android external execution contract.",
    "0.2.0",
)
class PluginTemplate(Star):
    def __init__(self, context: Context, config: dict | None = None):
        super().__init__(context)
        self.config = config or {}

    @filter.command_group("template")
    def template_plugin(self):
        """Template plugin command group."""
        pass

    @template_plugin.command("hello")
    async def say_hello(self, event: AstrMessageEvent):
        prefix = str(self.config.get("greeting_prefix", "Hello"))
        target = str(self.config.get("default_target", "AstrBot"))
        style = str(
            self.config.get(
                "response_style",
                "This template now includes a runnable Android execution contract sample.",
            ),
        ).strip()
        include_tip = bool(self.config.get("show_usage_tip", True))

        lines = [f"{prefix}, {target}!", style]
        if include_tip:
            lines.append(
                "Next step: replace the command, update android-execution.json, and implement your own runtime entry.",
            )

        yield event.plain_result("\n".join(lines))
