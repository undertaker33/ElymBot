# Greeting Toolkit Android Sample

这个样例现在使用 QuickJS 外部执行入口：

- `android-execution.json`
- `runtime/index.js`
- `_conf_schema.json`
- `assets/prompts/default.txt`

它主要用于验证：

- 本地 zip 安装
- `js_quickjs` 合同发现与绑定
- `runtime/index.js#handleEvent` 入口路径
- 轻量级 `text` / `card` 结果消费
- 静态配置提取
