const PROMPT_ASSET_URI = "plugin://package/assets/prompts/default.txt";

export function handleEvent(context) {
  const trigger = String(context?.trigger || "unknown");
  if (trigger === "on_plugin_entry_click") {
    return {
      resultType: "card",
      card: {
        title: "Greeting Toolkit",
        body:
          "QuickJS greeting sample is ready.\n" +
          `Trigger: ${trigger}\n` +
          `Prompt asset: ${PROMPT_ASSET_URI}`,
        status: "info"
      }
    };
  }
  return {
    resultType: "text",
    text:
      `Greeting Toolkit quickjs runtime handled ${trigger}. ` +
      `Prompt asset: ${PROMPT_ASSET_URI}`
  };
}
