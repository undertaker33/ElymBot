﻿# Meme Manager Android Sample

Version: 1.1.0

This sample package uses the QuickJS external execution contract:
- android-execution.json
- runtime/index.js
- media/settings_ui/host_action result fixtures
