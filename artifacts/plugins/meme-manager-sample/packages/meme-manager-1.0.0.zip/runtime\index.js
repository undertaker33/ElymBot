const DEFAULT_CATEGORY = "angry";
const WORKSPACE_IMPORT_PREFIX = "plugin://workspace/imports/";
const OPEN_HOST_PAGE_ACTION = "open_host_page";
const MANAGEMENT_PREFIX = "/表情管理";

const PACKAGED_MEMES = {
  angry: [
    {
      source:
        "plugin://package/resources/memes/angry/9D03FF21BB828C2AF9CCC7FCCB1E25B3.jpg",
      mimeType: "image/jpeg",
      altText: "angry meme"
    }
  ],
  happy: [
    {
      source: "plugin://package/resources/memes/happy/1739433254_1.png",
      mimeType: "image/png",
      altText: "happy meme"
    }
  ],
  sad: [
    {
      source: "plugin://package/resources/memes/sad/1739433848_1.jpg",
      mimeType: "image/jpeg",
      altText: "sad meme"
    }
  ],
  sleep: [
    {
      source: "plugin://package/resources/memes/sleep/1739433751_1.jpg",
      mimeType: "image/jpeg",
      altText: "sleep meme"
    }
  ],
  reply: [
    {
      source: "plugin://package/resources/memes/reply/1739433905_1.gif",
      mimeType: "image/gif",
      altText: "reply meme"
    }
  ],
  work: [
    {
      source:
        "plugin://package/resources/memes/work/6cbd639997ed76fb3830e1a3a56c56f5.jpg",
      mimeType: "image/jpeg",
      altText: "work meme"
    }
  ]
};

const CATEGORY_HINTS = {
  angry: ["angry", "生气", "愤怒", "吐槽", "不满"],
  happy: ["happy", "开心", "高兴", "庆祝", "nice"],
  sad: ["sad", "难过", "伤心", "抱歉", "遗憾"],
  sleep: ["sleep", "困", "晚安", "睡觉", "休息"],
  reply: ["reply", "回复", "等你", "消息", "回一下"],
  work: ["work", "工作", "进度", "处理", "开工"]
};

function buildSettingsUi() {
  return {
    resultType: "settings_ui",
    schema: {
      title: "Meme Manager",
      sections: [
        {
          sectionId: "admin",
          title: "Admin",
          fields: [
            {
              fieldType: "text_input",
              fieldId: "defaultCategory",
              label: "Default category",
              placeholder: "angry",
              defaultValue: DEFAULT_CATEGORY
            }
          ]
        }
      ]
    }
  };
}

function buildGalleryLines() {
  const categories = Object.keys(PACKAGED_MEMES).sort();
  const lines = ["当前图库："];
  for (const category of categories) {
    const count = PACKAGED_MEMES[category].length;
    lines.push(
      `- ${category}: 内置 ${count}，工作区导入前缀 ${WORKSPACE_IMPORT_PREFIX}${category}/`
    );
  }
  return lines.join("\n");
}

function buildStatsText() {
  const categories = Object.keys(PACKAGED_MEMES);
  const total = categories.reduce(
    (sum, category) => sum + PACKAGED_MEMES[category].length,
    0
  );
  return `图库统计：分类 ${categories.length} 个，内置 ${total} 张。`;
}

function pickCategory(rawCategory) {
  const normalized = String(rawCategory || "").trim().toLowerCase();
  if (normalized && PACKAGED_MEMES[normalized]) {
    return normalized;
  }
  return DEFAULT_CATEGORY;
}

function buildMedia(category) {
  const selectedCategory = pickCategory(category);
  return {
    resultType: "media",
    items: PACKAGED_MEMES[selectedCategory]
  };
}

function buildOpenPage(route, title) {
  return {
    resultType: "host_action",
    action: OPEN_HOST_PAGE_ACTION,
    title,
    payload: { route }
  };
}

function inferCategoryFromMessage(content) {
  const lowered = String(content || "").toLowerCase();
  for (const [category, hints] of Object.entries(CATEGORY_HINTS)) {
    if (hints.some((hint) => lowered.includes(hint.toLowerCase()))) {
      return category;
    }
  }
  return "";
}

function readMessageText(context) {
  return String(context?.message?.contentPreview || "").trim();
}

function handleCommand(context) {
  const messageText = readMessageText(context);
  if (messageText.startsWith("/meme")) {
    const category = messageText.replace("/meme", "").trim().split(/\s+/)[0];
    return buildMedia(category);
  }

  if (!messageText.startsWith(MANAGEMENT_PREFIX)) {
    return {
      resultType: "noop",
      reason: "Command not handled by meme manager"
    };
  }

  const action = messageText.slice(MANAGEMENT_PREFIX.length).trim();
  const pluginId = String(
    context?.pluginId || "com.astrbot.plugins.meme_manager.android"
  );

  if (!action || action === "帮助") {
    return {
      resultType: "text",
      text:
        "表情管理命令：\n" +
        "- /meme <分类>\n" +
        "- /表情管理 查看图库\n" +
        "- /表情管理 图库统计\n" +
        "- /表情管理 打开工作台\n" +
        "- /表情管理 打开配置"
    };
  }
  if (action === "查看图库") {
    return { resultType: "text", text: buildGalleryLines() };
  }
  if (action === "图库统计") {
    return { resultType: "text", text: buildStatsText() };
  }
  if (action === "打开工作台") {
    return buildOpenPage(`plugins/detail/${pluginId}/workspace`, "打开工作台");
  }
  if (action === "打开配置") {
    return buildOpenPage(`plugins/detail/${pluginId}/config`, "打开配置");
  }
  return {
    resultType: "text",
    text:
      "当前 QuickJS 样例保留了工作区 URI 合同，但不在脚本内直接扫描文件系统。\n" +
      `工作区导入前缀：${WORKSPACE_IMPORT_PREFIX}`
  };
}

export function handleEvent(context) {
  const trigger = String(context?.trigger || "");
  if (trigger === "on_plugin_entry_click") {
    return buildSettingsUi();
  }
  if (trigger === "on_command") {
    return handleCommand(context);
  }
  if (trigger === "after_model_response") {
    return buildMedia(inferCategoryFromMessage(readMessageText(context)));
  }
  if (trigger === "before_send_message") {
    return {
      resultType: "noop",
      reason: "before_send_message not used for meme injection"
    };
  }
  return {
    resultType: "noop",
    reason: `Unsupported trigger: ${trigger || "unknown"}`
  };
}
